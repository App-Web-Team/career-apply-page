<head>
    <link rel="stylesheet" href="assets/styles/style-form-1.css">
</head>

<!-- <div class="contact-container">
    <form action="#"> -->
<!-- <p class="touch-text fw-bold">
            Get in Touch
        </p> -->
<p class="details-heading text-capitalize">
    personal details
</p>
<div class="form-row text-left mt-4 mb-4">
    <div class="d-flex flex-row">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">first Name</label>
        </div>
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">last Name</label>
        </div>
    </div>
</div>
<div class="form-row text-left mb-4">
    <div class="d-flex flex-row">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">phone no.</label>
        </div>
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">email id</label>
        </div>
    </div>
</div>
<div class="form-row text-left mb-4">
    <div class="">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">address</label>
        </div>
    </div>
</div>
<div class="form-row text-left mb-4">
    <div class="d-flex flex-row">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">state</label>
        </div>
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">pincode</label>
        </div>
    </div>
</div>
<div class="form-row text-left mb-4">
    <div class="d-flex flex-row">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">father's name</label>
        </div>
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">father's occupation</label>
        </div>
    </div>
</div>
<div class="form-row text-left mb-4">
    <div class="d-flex flex-row">
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">mother's name</label>
        </div>
        <div class="input-data">
            <input type="text" required>
            <div class="underline"></div>
            <label for="">mother's occupation</label>
        </div>
    </div>
</div>


<!-- <div class="form-row d-flex justify-content-center">
            <div class="form-row submit-btn">
                <div class="input-data">
                    <button type="button" class="submit-button btn btn-danger">Submit</button>
                </div>
            </div>
        </div> -->
<!-- </form>
</div> -->